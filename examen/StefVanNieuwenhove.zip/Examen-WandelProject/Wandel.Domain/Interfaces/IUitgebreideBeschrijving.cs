namespace Domein.Wandel.Interfaces;


public interface IUitgebreideBeschrijving {

    public string UitegebreideBeschrijving { get; }
}