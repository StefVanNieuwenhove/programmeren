namespace Domein.Wandel.Exceptions; 

public class TochException : Exception {

    public TochException() : base() {}

    public TochException(string message) : base(message) {}
}